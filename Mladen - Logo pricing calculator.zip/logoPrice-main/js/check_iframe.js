if(window.location !== window.parent.location) {
    document.querySelector('header').style.display = 'none';
}