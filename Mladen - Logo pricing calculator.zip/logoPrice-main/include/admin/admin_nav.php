<header>
    <nav class="navigation navigation-admin">
            <div id="sidebar-toggle">
                <i class="fas fa-bars"></i>
            </div>
        <ul class="navigation__menu">
            <li>
                <a href="<?php base(); ?>index" class="navigation__link">Home</a>
            </li>
            <li>
                <a href="<?php base(); ?>calculators" class="navigation__link tablet">Dashboard</a>
            </li>
            <li>
                <a href="<?php base(); ?>create_calc" class="navigation__link desktop">Create New Calculator</a>
            </li>
            <li>
                <a href="<?php base(); ?>include/logout.inc.php" class="navigation__link">Logout</a>
            </li>
        </ul>
    </nav>
</header>