<script src="scripts/modernizr-3.11.2.min.js"></script>
<script src="scripts/scripts.js"></script>