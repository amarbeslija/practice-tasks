<!-- Insert here all additional HTML if needed (outside main content, for example: modal windows, etc.) -->

<!-- Main Footer -->
<footer id="main-footer">
    <div class="upper-footer"></div>
    <div class="bottom-footer"></div>
</footer>

<?php
/*** S: Load all JavaScript files from scripts module ***/
require 'modules/scripts.module.php';
/*** E: Load all JavaScript files from scripts module ***/

/*** S: Load Google Analytics ***/
require 'modules/analytics.module.php';
/*** E: Load Google Analytics ***/